# HELLO 
Squid repo here, use these plugins at your discretion.
----
[<img src="https://img.shields.io/badge/Support-me!-orange.svg">](https://www.patreon.com/tekulvw) [![Code Climate](https://codeclimate.com/github/tekulvw/Squid-Plugins/badges/gpa.svg)](https://codeclimate.com/github/tekulvw/Squid-Plugins)
I'll get to the docs *eventually*


[smart questions](http://www.catb.org/esr/faqs/smart-questions.html)