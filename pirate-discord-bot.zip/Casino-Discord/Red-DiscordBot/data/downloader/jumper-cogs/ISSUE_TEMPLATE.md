**Note: for support questions, please use the [Cog Support Server](https://discord.gg/c6HQUb7)**. This repository's issues are reserved for feature requests and bug reports.

# I'm submitting a ...
- [ ] bug report
- [ ] feature request
- [ ] support request => Please do not submit support request here, see note at the top of this template.


# **Cog Information**

Name:  
Version:

# Feature Description
*Please include the motivation / use case for this feature.*

# Bug Report
**Screenshot of console: (If Applicable)**

**Command used:**

**Expected result:**

**Steps to reproduce:**

**Please tell me about your environment/OS:**
